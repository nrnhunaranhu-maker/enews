// FRAG.MN — Main JS

document.addEventListener('DOMContentLoaded', () => {

  // --- NAV ACTIVE ---
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
    });
  });

  // --- FILTER TABS ---
  const filterTabs = document.querySelectorAll('.filter-tab');
  filterTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      filterTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
    });
  });

  // --- PAGE BUTTONS ---
  const pageBtns = document.querySelectorAll('.page-btn');
  pageBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      pageBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // --- SEARCH ---
  const searchInput = document.querySelector('.search-input');
  const searchBtn = document.querySelector('.search-btn');
  if (searchBtn) {
    searchBtn.addEventListener('click', () => {
      const q = searchInput.value.trim();
      if (q) {
        console.log('Searching:', q);
        // Future: filter news items
      }
    });
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') searchBtn.click();
    });
  }

  // --- LIVE SCORE ANIMATION ---
  // Simulate score changes for the live matches
  const scores = document.querySelectorAll('.score');
  if (scores.length >= 2) {
    setInterval(() => {
      // Animate score flash effect
      scores.forEach(s => {
        s.style.transition = 'color 0.3s';
        s.style.color = 'var(--accent3)';
        setTimeout(() => { s.style.color = '#fff'; }, 400);
      });
    }, 8000);
  }

  // --- NEWS ITEM CLICK ---
  document.querySelectorAll('.news-item').forEach(item => {
    item.addEventListener('click', () => {
      item.style.borderColor = 'var(--accent)';
      setTimeout(() => { item.style.borderColor = ''; }, 600);
    });
  });

  // --- STAGGERED ENTRANCE ANIMATION ---
  const newsItems = document.querySelectorAll('.news-item');
  newsItems.forEach((item, i) => {
    item.style.opacity = '0';
    item.style.transform = 'translateX(-16px)';
    setTimeout(() => {
      item.style.transition = 'opacity 0.4s ease, transform 0.4s ease, border-color 0.2s, background 0.2s';
      item.style.opacity = '1';
      item.style.transform = 'translateX(0)';
    }, 80 + i * 60);
  });

  // Hero card entrance
  const mainCard = document.querySelector('.main-card');
  if (mainCard) {
    mainCard.style.opacity = '0';
    mainCard.style.transform = 'translateY(16px)';
    setTimeout(() => {
      mainCard.style.transition = 'opacity 0.5s ease, transform 0.5s ease, border-color 0.3s, box-shadow 0.3s';
      mainCard.style.opacity = '1';
      mainCard.style.transform = 'translateY(0)';
    }, 100);
  }

  document.querySelectorAll('.side-card').forEach((card, i) => {
    card.style.opacity = '0';
    card.style.transform = 'translateX(16px)';
    setTimeout(() => {
      card.style.transition = 'opacity 0.4s ease, transform 0.4s ease, border-color 0.2s, box-shadow 0.2s';
      card.style.opacity = '1';
      card.style.transform = 'translateX(0)';
    }, 200 + i * 80);
  });

  // --- MATCH BAR ANIMATION ---
  const fills = document.querySelectorAll('.match-fill');
  fills.forEach(fill => {
    const target = fill.style.width;
    fill.style.width = '0%';
    setTimeout(() => {
      fill.style.transition = 'width 1.2s cubic-bezier(0.4,0,0.2,1)';
      fill.style.width = target;
    }, 600);
  });

  // --- GLITCH EFFECT on logo hover ---
  const logoText = document.querySelector('.logo-text');
  if (logoText) {
    let glitching = false;
    logoText.closest('.logo').addEventListener('mouseenter', () => {
      if (glitching) return;
      glitching = true;
      const original = logoText.textContent;
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$%&';
      let i = 0;
      const iv = setInterval(() => {
        logoText.textContent = original.split('').map((c, idx) =>
          idx < i ? c : chars[Math.floor(Math.random() * chars.length)]
        ).join('');
        i++;
        if (i > original.length) {
          clearInterval(iv);
          logoText.textContent = original;
          glitching = false;
        }
      }, 40);
    });
  }

});
